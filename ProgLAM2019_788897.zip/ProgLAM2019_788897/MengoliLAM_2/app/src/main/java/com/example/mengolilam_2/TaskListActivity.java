package com.example.mengolilam_2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.database.Cursor;
import android.content.Intent;
import android.view.View;

import com.example.mengolilam_2.ui.category.CategoryFragment;


public class TaskListActivity extends AppCompatActivity {
    private TextView category;
    private ListView list;
    private GestioneDB db ;
    private String cat;
    private TextView numpend, numong, numcomp;
    private MainActivity main;
    private ImageButton btnEditCat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);
        category = findViewById(R.id.category_title);
        list = findViewById(R.id.category_task_list);
        numpend = findViewById(R.id.num_pending);
        numong = findViewById(R.id.num_ongoing);
        numcomp = findViewById(R.id.num_completed);
        btnEditCat = findViewById(R.id.edit_category);


        cat = getIntent().getStringExtra("category_title");
        category.setText(cat);
        db = new GestioneDB(this);
        db.open();
        impostaNumStati();
        Cursor c = db.ottieniTaskCategoria(cat);
        visualizzaTask(c);

            //spinner per i filtri
            Spinner spinner_filter = (Spinner) findViewById(R.id.filter_spinner);
            ArrayAdapter<CharSequence> adapter_filter = ArrayAdapter.createFromResource(this, R.array.filter_array, android.R.layout.simple_spinner_item);

        adapter_filter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner_filter.setAdapter(adapter_filter);
            spinner_filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String orderby ="";
                   switch(parent.getItemAtPosition(position).toString()){
                       case "Sort by date descending":
                           orderby = "datainizio DESC";
                           break;
                       case "Sort by date ascending":
                           orderby = "datainizio ASC";
                           break;
                       case "Sort by state":
                           orderby = "stato DESC";
                           break;
                   }
                   Cursor c = db.ottieniTaskOrdinati(orderby,category.getText().toString());
                   visualizzaTask(c);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spinner_filter.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(event.getAction() == MotionEvent.ACTION_BUTTON_PRESS){
                        return true;
                    }

                    return false;
                }
            });

            btnEditCat.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(TaskListActivity.this);
                    builder.setTitle("Change name category");

                    // Set up the input
                    final EditText input = new EditText(TaskListActivity.this);
                    // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                    input.setInputType(InputType.TYPE_CLASS_TEXT );
                    builder.setView(input);

                    // Set up the buttons
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Cursor c = db.ottieniIDCategoria(category.getText().toString());
                            c.moveToFirst();
                            db.aggiornaCategoria(input.getText().toString(),c.getInt(0));
                            category.setText(input.getText().toString());
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    builder.show();
                }
            });


    }
        @Override
        protected void onStart(){
            super.onStart();
        }

        @Override
        protected void onStop(){
            super.onStop();
            db.close();
        }

        @Override
        protected  void onResume(){
            super.onResume();
            db.open();
        }

        public void visualizzaTask(Cursor c) {
            if (c.moveToFirst()) {
                do {
                    TaskCursorAdapter taskadp = new TaskCursorAdapter(this, c);
                    taskadp.changeCursor(c);
                    list.setAdapter(taskadp);
                } while (c.moveToNext());
            }

        }

        public void openTaskDetail(View v){
            TextView id = v.findViewById(R.id.row_task_id);
            Intent intent = new Intent(TaskListActivity.this, TaskActivity.class);
            intent.putExtra("id",id.getText().toString());
            intent.putExtra("activity", "TaskListActivity");
            startActivity(intent);
        }

    public void impostaNumStati() {
        Cursor pend = db.ConteggioTask(category.getText().toString(), "pending");
        Cursor ongo = db.ConteggioTask(category.getText().toString(), "ongoing");
        Cursor comp = db.ConteggioTask(category.getText().toString(), "completed");

        pend.moveToFirst();
        numpend.setText(pend.getString(1));
        ongo.moveToFirst();
        numong.setText(ongo.getString(1));
        comp.moveToFirst();
        numcomp.setText(comp.getString(1));


    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(TaskListActivity.this, MainActivity.class);
        startActivity(intent);
    }

    public void deleteTask(View v){
       View parent =  v.getRootView();
        TextView id = parent.findViewById(R.id.row_task_id);
        Boolean bool = db.cancellaTask(Integer.parseInt(id.getText().toString()));
        if(bool) {
            Cursor c = db.ottieniTaskCategoria(cat);
            visualizzaTask(c);
        }
    }
    }


