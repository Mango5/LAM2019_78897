package com.example.mengolilam_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Iterator;


public class GestioneDB {

    //tabella TASK
    static final String DATABASE_TABELLA_TASK = "task";
    static final String KEY_ROWID = "_id";
    static final String KEY_TITOLO = "titolo";
    static final String KEY_STATO = "stato";
    static final String KEY_CATEGORIA  = "categoria";
    static final String KEY_PRIORITA = "priorita";
    static final String KEY_DATAINIZIO = "datainizio";
    static final String KEY_ORAINIZIO = "orainizio";
    static final String KEY_DATAFINE = "datafine";
    static final String KEY_ORAFINE = "orafine";
    static final String KEY_LUOGO = "luogo";
    static final String KEY_DESCRIZIONE = "descrizione";

    //tabella NOTIFICHE
    static final String DATABASE_TABELLA_NOT = "notifiche";
    static final String KEY_ID = "_id";
    static final String KEY_TASKID = "taskid";
    static final String KEY_IDREM = "idrem";

    //tabella CATEGORIA
    static final String DATABASE_TABELLA_CAT = "categoria";
    static final String KEY_CATID = "_id";
    static final String KEY_DESCRIZIONE_CAT = "descrizione";

    //tabella SHOPPINGLIST
    static final String DATABASE_TABELLA_SL = "shoppinglist";
    static final String KEY_LISTID = "_id";
    static final String KEY_NOME = "nome";
    static final String KEY_TOTALE = "totale";
    //tabella SHOPPINGITEM
    static final String DATABASE_TABELLA_ITEM = "shoppingitem";
    static final String KEY_ROWIDITEM = "_id";
    static final String KEY_SHOPID = "idlist";
    static final String KEY_ITEM = "item";
    static final String KEY_QUANTITY = "quantita";
    static final String KEY_PRICE = "prezzo";
    //tabella  REMINDER
    static final String DATABASE_TABELLA_REM = "reminder";
    static final String KEY_REMID = "_id";
    static final String KEY_DESCRIZIONE_REM = "descrizione";
    static final String KEY_MINUTI = "minuti";

    static final String TAG = "GestioneDB";
    static final String DATABASE_NOME = "TestDB.db";
    static final int DATABASE_VERSIONE = 4;




   static final String DATABASE_CREAZIONE_TASK =
            "CREATE TABLE "+ DATABASE_TABELLA_TASK + "("
                    + KEY_ROWID + " integer primary key autoincrement, "
                    + KEY_TITOLO + " text not null,"
                    + KEY_STATO + " text not null,"
                    + KEY_CATEGORIA + " text not null,"
                    + KEY_PRIORITA + " integer not null,"
                    + KEY_DATAINIZIO + " date not null,"
                    + KEY_ORAINIZIO + " time not null,"
                    + KEY_DATAFINE + " date,"
                    + KEY_ORAFINE + " time,"
                    + KEY_LUOGO + " text,"
                    + KEY_DESCRIZIONE +" text"
                    + ");";

    static final String DATABASE_CREAZIONE_NOT =
            "CREATE TABLE " + DATABASE_TABELLA_NOT + " ("
                    + KEY_ID+ " integer primary key autoincrement, "
                    + KEY_TASKID + " integer not null,"
                    + KEY_IDREM + " integer "
                    + ");";

    static final String DATABASE_CREAZIONE_CAT =
            "CREATE TABLE " + DATABASE_TABELLA_CAT + " ("
                    + KEY_CATID+ " integer primary key autoincrement, "
                    + KEY_DESCRIZIONE_CAT + " text not null"
                    + ");";

    static final String DATABASE_CREAZIONE_SL =
            "CREATE TABLE " + DATABASE_TABELLA_SL + " ("
                    + KEY_LISTID+ " integer primary key autoincrement, "
                    + KEY_NOME + " text not null,"
                    + KEY_TOTALE + " smallint "
                    + ");";

    static final String DATABASE_CREAZIONE_ITEM=
            "CREATE TABLE " + DATABASE_TABELLA_ITEM + "("
                    + KEY_ROWIDITEM+ " integer primary key autoincrement, "
                    + KEY_SHOPID + " integer not null,"
                    + KEY_ITEM + " text not null,"
                    + KEY_QUANTITY + " integer ,"
                    + KEY_PRICE + " smallint"
                    + ");";

    static final String DATABASE_CREAZIONE_REM=
            "CREATE TABLE " + DATABASE_TABELLA_REM + " ("
                    + KEY_REMID+ " integer primary key autoincrement, "
                    + KEY_DESCRIZIONE_REM + " text not null,"
                    + KEY_MINUTI + " integer not null"
                    + ");";


    final Context context;
    DatabaseHelper DBHelper;
    SQLiteDatabase db;

    public GestioneDB(Context ctx)
    {
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper{

        DatabaseHelper(Context context)
        {
            super(context, DATABASE_NOME, null, DATABASE_VERSIONE);
        }

        @Override
        public void onCreate(SQLiteDatabase db){
            try {
                db.execSQL(DATABASE_CREAZIONE_TASK);
                db.execSQL(DATABASE_CREAZIONE_NOT);
                db.execSQL(DATABASE_CREAZIONE_CAT);
                db.execSQL(DATABASE_CREAZIONE_SL);
                db.execSQL(DATABASE_CREAZIONE_ITEM);
                db.execSQL(DATABASE_CREAZIONE_REM);

            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
            Log.w(DatabaseHelper.class.getName(),"Aggiornamento database dalla versione " + oldVersion + " alla "
                    + newVersion + ". I dati esistenti verranno eliminati.");
            db.execSQL("DROP TABLE IF EXISTS task");
            db.execSQL("DROP TABLE IF EXISTS notifiche");
            db.execSQL("DROP TABLE IF EXISTS categoria");
            db.execSQL("DROP TABLE IF EXISTS shoppinglist");
            db.execSQL("DROP TABLE IF EXISTS shoppingitem");
            db.execSQL("DROP TABLE IF EXISTS reminder");
            onCreate(db);
        }
    }

    public GestioneDB open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }


    public void close()
    {
        DBHelper.close();
    }

    public void onCreate(){
        Cursor c = db.rawQuery("SELECT * FROM "+ DATABASE_TABELLA_CAT, null);
        if (c.getCount() == 0) {
            insertCategorie();
        }
        Cursor r = db.rawQuery("SELECT * FROM "+ DATABASE_TABELLA_REM, null);
        if(r.getCount() == 0){
            insertReminder();
        }

    }

//region Task

    public long inserisciTask(String task){

        try {
            ContentValues initialValues = new ContentValues();
            Gson gson = new Gson();
            JsonObject obj = gson.fromJson(task, JsonObject.class);
            if (obj.get("titolo") != null ) {
                initialValues.put(KEY_TITOLO, obj.get("titolo").getAsString());
            }
            if (obj.get("stato") != null ) {
                initialValues.put(KEY_STATO, obj.get("stato").getAsString());
            }
            if (obj.get("categoria") != null ) {
                initialValues.put(KEY_CATEGORIA, obj.get("categoria").getAsString());
            }
            if (obj.get("priorita") != null  ) {
                initialValues.put(KEY_PRIORITA, obj.get("priorita").getAsInt());
            }
            if (obj.get("datainizio") != null ) {
                initialValues.put(KEY_DATAINIZIO, obj.get("datainizio").getAsString());
            }
            if (obj.get("orainizio") != null ) {
                initialValues.put(KEY_ORAINIZIO, obj.get("orainizio").getAsString());
            }
            if (obj.get("datafine") != null ) {
                initialValues.put(KEY_DATAFINE, obj.get("datafine").getAsString());
            }
            if (obj.get("orafine") != null ) {
                initialValues.put(KEY_ORAFINE, obj.get("orafine").getAsString());
            }
            if (obj.get("luogo") != null ) {
                initialValues.put(KEY_LUOGO, obj.get("luogo").getAsString());
            }
            if (obj.get("descrizione") != null ) {
                initialValues.put(KEY_DESCRIZIONE, obj.get("descrizione").getAsString());
            }
            return db.insert(DATABASE_TABELLA_TASK, null, initialValues);
        }catch (Exception ex){
            System.out.println(ex);
            return 0;
        }
    }

    public boolean cancellaTask(long id){
        return db.delete(DATABASE_TABELLA_TASK, KEY_ROWID + "=" + id, null) > 0;
    }

    public Cursor ottieniCountTaskMese(Integer idcategoria, Integer month){
        return db.rawQuery("SELECT task._id, COUNT(*)  FROM " + DATABASE_TABELLA_TASK + " INNER JOIN " + DATABASE_TABELLA_CAT  + " ON task.categoria = categoria.descrizione WHERE categoria._id = " + idcategoria +" AND strftime('%m', task.datainizio) = " + month, null);
    }

    public Cursor ottieniCountTaskCategoria(String categoria, String stato){
        return db.rawQuery("SELECT task._id, COUNT(*)  FROM " + DATABASE_TABELLA_TASK  + " WHERE task.categoria = '"+ categoria + "' AND task.stato = '" + stato +"'", null);
    }
    public Cursor ottieniTuttiTask(){
        return db.query(DATABASE_TABELLA_TASK, new String[] {
                KEY_ROWID,
                KEY_TITOLO,
                KEY_STATO,
                KEY_CATEGORIA,
                KEY_PRIORITA,
                KEY_DATAINIZIO,
                KEY_ORAINIZIO,
                KEY_DATAFINE,
                KEY_ORAFINE,
                KEY_LUOGO,
                KEY_DESCRIZIONE}, null, null, null, null, null);
    }

    public Cursor ottieniTask(int id){
        return db.query(DATABASE_TABELLA_TASK, new String[] {
                KEY_ROWID,
                KEY_TITOLO,
                KEY_STATO,
                KEY_CATEGORIA,
                KEY_PRIORITA,
                KEY_DATAINIZIO,
                KEY_ORAINIZIO,
                KEY_DATAFINE,
                KEY_ORAFINE,
                KEY_LUOGO,
                KEY_DESCRIZIONE}, KEY_ROWID + " = " + id , null, null, null, null);
    }


    public Cursor ottieniTaskCategoria(String categoria){
        return db.query(DATABASE_TABELLA_TASK, new String[] {
                KEY_ROWID,
                KEY_TITOLO,
                KEY_PRIORITA,
                KEY_DATAINIZIO,
                KEY_DATAFINE,
                KEY_STATO
                },  KEY_CATEGORIA + " = '" + categoria+ "'" , null, null, null, null);
    }

    public Cursor ottieniTaskOrdinati(String orderby, String categoria){
        return db.query(DATABASE_TABELLA_TASK, new String[] {
                KEY_ROWID,
                KEY_TITOLO,
                KEY_PRIORITA,
                KEY_DATAINIZIO,
                KEY_DATAFINE,
                KEY_STATO
        },  KEY_CATEGORIA + " = '" + categoria+ "'" , null, null, null, orderby);
    }
    
    public Cursor ottieniTaskData(String data){
        return db.query(DATABASE_TABELLA_TASK, new String[] {
                KEY_ROWID,
                KEY_TITOLO,
                KEY_PRIORITA,
                KEY_DATAINIZIO,
                KEY_DATAFINE,
                KEY_STATO
        },  KEY_DATAINIZIO + " = '" + data + "'" , null, null, null, null);
    }
    public boolean aggiornaTask(String task, int id){
        try {
            ContentValues args = new ContentValues();
            Gson gson = new Gson();
            JsonObject obj = gson.fromJson(task, JsonObject.class);
            args.put(KEY_TITOLO, obj.get("titolo").getAsString());
            args.put(KEY_STATO, obj.get("stato").getAsString());
            args.put(KEY_CATEGORIA, obj.get("categoria").getAsString());
            if(obj.get("priorita") != null ) {
                args.put(KEY_PRIORITA, obj.get("priorita").getAsString());
            }
            if(obj.get("datainizio") != null ) {
                args.put(KEY_DATAINIZIO, obj.get("datainizio").getAsString());
            }
            if(obj.get("orainizio") != null ) {
                args.put(KEY_ORAINIZIO, obj.get("orainizio").getAsString());
            }
            if(obj.get("datafine") != null ) {
                args.put(KEY_DATAFINE, obj.get("datafine").getAsString());
            }
            if(obj.get("orafine") != null ) {
                args.put(KEY_ORAFINE, obj.get("orafine").getAsString());
            }
            if(obj.get("luogo") != null ) {
                args.put(KEY_LUOGO, obj.get("luogo").getAsString());
            }
            if(obj.get("descrizione") != null ) {
                args.put(KEY_DESCRIZIONE, obj.get("descrizione").getAsString());
            }
            return db.update(DATABASE_TABELLA_TASK, args, KEY_ROWID + "=" + id, null) > 0;
        }catch(Exception ex){
            System.out.println(ex);
            return false;
        }
    }

    public Cursor ConteggioTask(String categoria, String stato){
        return db.query(DATABASE_TABELLA_TASK, new String[] {
                KEY_ROWID,
                "COUNT(*) AS NUM"
        },  KEY_CATEGORIA + " = '" + categoria + "' AND " + KEY_STATO + " = '" + stato + "'" , null, null, null, null);

    }

//endregion

//region Notifiche
    public long inserisciNotifiche(int idrem, int idtask){
        try{
                ContentValues initialValues = new ContentValues();
                initialValues.put(KEY_IDREM, idrem);
                initialValues.put(KEY_TASKID, idtask);
               return db.insert(DATABASE_TABELLA_NOT, null, initialValues);
        }catch (Exception ex){
            System.out.println(ex);
            return 0;
        }
    }

    public void cancellaNotifica(int taskid){
         db.delete(DATABASE_TABELLA_NOT, KEY_TASKID + "=" + taskid, null) ;
    }
    public Cursor ottieniNotifiche(int id){
        return db.query(DATABASE_TABELLA_NOT, new String[] {
                KEY_TASKID,
                KEY_IDREM}, KEY_TASKID + "=" + id , null, null, null, null);
    }
//endregion

//region Categoria

    public Cursor ottieniCategorie(){
        return db.query(true,DATABASE_TABELLA_CAT, new String[] {
                KEY_CATID,
                KEY_DESCRIZIONE_CAT
        },  null, null, KEY_DESCRIZIONE_CAT, null, null,null);
    }

    public Cursor ottieniIDCategoria(String categoria){
        return db.query(true,DATABASE_TABELLA_CAT, new String[] {
                KEY_CATID
        },  KEY_DESCRIZIONE_CAT + " = '" + categoria + "'", null, null, null, null,null);
    }
    public boolean aggiornaCategoria(String categoria, int id){
        try{
        ContentValues args = new ContentValues();
        args.put(KEY_DESCRIZIONE_CAT, categoria);
        return db.update(DATABASE_TABELLA_CAT, args, KEY_CATID + "=" + id, null) > 0;
        }catch(Exception ex){
            System.out.println(ex);
            return false;
        }
    }

    public long inserisciCategoria(String categoria){
        try{
            ContentValues args = new ContentValues();
            args.put(KEY_DESCRIZIONE_CAT, categoria);
            return db.insert(DATABASE_TABELLA_CAT, null, args);
        }catch(Exception ex){
            System.out.println(ex);
            return 0;
        }
    }


//endregion

//region ShoopinList

    public Cursor ottieniShoppingList(){
        return db.query(DATABASE_TABELLA_SL, new String[] {
                KEY_LISTID,
                KEY_NOME,
                KEY_TOTALE
        },  null, null, null, null, null);
    }

    public boolean aggiornaShoppingList(String list, int id){
        try{
            ContentValues args = new ContentValues();
            Gson gson = new Gson();
            JsonObject obj = gson.fromJson(list, JsonObject.class);
            if( obj.get("nome") != null) {
                args.put(KEY_NOME, obj.get("nome").getAsString());
            }
            if( obj.get("totale") != null) {
                args.put(KEY_TOTALE, obj.get("totale").getAsDouble());
            }
            return db.update(DATABASE_TABELLA_SL, args, KEY_LISTID + "=" + id, null) > 0;
        }catch(Exception ex){
            System.out.println(ex);
            return false;
        }
    }

    public long inserisciShoppingList(String nomelist){
        try{
            ContentValues args = new ContentValues();

            if( nomelist != null) {
                args.put(KEY_NOME, nomelist);
            }
            args.put(KEY_TOTALE, 0);
            return db.insert(DATABASE_TABELLA_SL, null, args);
        }catch(Exception ex){
            System.out.println(ex);
            return 0;
        }
    }

    public boolean eliminaShoppingList(int id){
        if( eliminaTuttiShoppingItem(id)){
            return db.delete(DATABASE_TABELLA_SL,KEY_LISTID + "=" + id,null) > 0;
        }
        return false;
    }


//endregion

//region ShoppingItem

    public Cursor ottieniShoppingItem(Integer idList){
        return db.query(DATABASE_TABELLA_ITEM, new String[] {
                KEY_ROWIDITEM,
                KEY_ITEM,
                KEY_QUANTITY,
                KEY_PRICE
        },  null, null, null, null, null);
    }

    public boolean aggiornaShoppingItem(String item, int id){
        try{
            ContentValues args = new ContentValues();
            Gson gson = new Gson();
            JsonObject obj = gson.fromJson(item, JsonObject.class);
            if(obj.get("item") != null) {
                args.put(KEY_ITEM, obj.get("item").getAsString());
            }
            if(obj.get("quantita") != null) {
                args.put(KEY_QUANTITY, obj.get("quantita").getAsString());
            }
            if(obj.get("prezzo") != null) {
                args.put(KEY_PRICE, obj.get("prezzo").getAsString());
            }
            return db.update(DATABASE_TABELLA_ITEM, args, KEY_ROWIDITEM + "=" + id, null) > 0;
        }catch(Exception ex){
            System.out.println(ex);
            return false;
        }
    }

    public boolean eliminaShoppingItem(int id){
        return db.delete(DATABASE_TABELLA_ITEM,KEY_ROWIDITEM + "=" + id,null) > 0;
    }

    public Cursor conteggioTotale(int idlist){
        return db.rawQuery("SELECT _id,(quantita * prezzo) as prezzotot FROM shoppingitem", null);
    }

    public boolean eliminaTuttiShoppingItem(int idlist){
        return db.delete(DATABASE_TABELLA_ITEM,KEY_SHOPID + "=" + idlist,null) > 0;
    }

    public long inserisciShoppingItem(String item, int idList){
        try{
            ContentValues args = new ContentValues();
            Gson gson = new Gson();
            JsonObject obj = gson.fromJson(item, JsonObject.class);
            args.put(KEY_SHOPID, idList);
            if(obj.get("item") != null) {
                args.put(KEY_ITEM, obj.get("item").getAsString());
            }
            if(obj.get("quantita") != null) {
                args.put(KEY_QUANTITY, obj.get("quantita").getAsString());
            }
            if(obj.get("prezzo") != null) {
                args.put(KEY_PRICE, obj.get("prezzo").getAsString());
            }
            return db.insert(DATABASE_TABELLA_ITEM, null, args);
        }catch(Exception ex){
            System.out.println(ex);
            return 0;
        }
    }


//endregion

    public void insertCategorie(){
        try{
            ContentValues args = new ContentValues();
            args.put(KEY_DESCRIZIONE_CAT, "Work");
            db.insert(DATABASE_TABELLA_CAT, null, args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_CAT, "University");
            db.insert(DATABASE_TABELLA_CAT, null, args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_CAT, "Sport");
            db.insert(DATABASE_TABELLA_CAT, null, args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_CAT, "Other");
            db.insert(DATABASE_TABELLA_CAT, null, args);

        } catch(Exception ex){
            System.out.println(ex);
        }

    }

    public void insertReminder(){
        try{
            ContentValues args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "5 minuti prima");
            args.put(KEY_MINUTI, 5);
            db.insert(DATABASE_TABELLA_REM,null,args);

             args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "10 minuti prima");
            args.put(KEY_MINUTI, 10);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "15 minuti prima");
            args.put(KEY_MINUTI, 15);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "30 minuti prima");
            args.put(KEY_MINUTI, 30);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "1 ora prima");
            args.put(KEY_MINUTI, 60);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "2 ore prima");
            args.put(KEY_MINUTI, 120);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "24 ore prima");
            args.put(KEY_MINUTI, 1440);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "2 giorni prima");
            args.put(KEY_MINUTI, 2880);
            db.insert(DATABASE_TABELLA_REM,null,args);

            args = new ContentValues();
            args.put(KEY_DESCRIZIONE_REM, "1 settimana prima");
            args.put(KEY_MINUTI, 10080);
            db.insert(DATABASE_TABELLA_REM,null,args);

        }catch(Exception ex){
            System.out.println(ex);
    }
    }

    public Cursor ottieniTuttiReminder(){
        return db.query(true, DATABASE_TABELLA_REM,new String[] {
                KEY_REMID,
                KEY_DESCRIZIONE_REM
        },null, null, null, null, null, null);
    }

    public Cursor ottieniReminder(int id){
        return db.query(true, DATABASE_TABELLA_REM,new String[] {
                KEY_REMID,
                KEY_DESCRIZIONE_REM
        },KEY_REMID +"=" + id, null, null, null, null, null);
    }
}
