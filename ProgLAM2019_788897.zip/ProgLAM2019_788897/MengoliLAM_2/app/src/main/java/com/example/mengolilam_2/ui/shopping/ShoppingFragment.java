package com.example.mengolilam_2.ui.shopping;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.mengolilam_2.GestioneDB;
import com.example.mengolilam_2.R;
import com.example.mengolilam_2.TaskCursorAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ShoppingFragment extends Fragment {
    private ListView list;
    private TextView nome,totale;
    private ShoppingViewModel shoppingViewModel;
    private GestioneDB db;
    private View root;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        shoppingViewModel =
                ViewModelProviders.of(this).get(ShoppingViewModel.class);
        root = inflater.inflate(R.layout.fragment_shopping, container, false);

        db = new GestioneDB(root.getContext());
        db.open();

        list = root.findViewById(R.id.shopping_list);
        totale = root.findViewById(R.id.row_shoplist_totale);
        nome = root.findViewById(R.id.row_shoplist_nome);


        Cursor c = db.ottieniShoppingList();
        visualizzaList(c);

        View view = getActivity().findViewById(R.id.drawer_layout);
        FloatingActionButton fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(root.getContext());
                builder.setTitle("Add new shopping list");

                // Set up the input
                final EditText input = new EditText(root.getContext());
                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                input.setInputType(InputType.TYPE_CLASS_TEXT );
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       Long id =  db.inserisciShoppingList(input.getText().toString());
                        Cursor c = db.ottieniShoppingList();
                        if(c.getCount() > 0) {
                            visualizzaList(c);
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });
        return root;
    }

    public void visualizzaList(Cursor c) {
        if (c.moveToFirst()) {
            do {
                ShopListCursorAdapter shopadp = new ShopListCursorAdapter(root.getContext(), c);
                shopadp.changeCursor(c);
                list.setAdapter(shopadp);
            } while (c.moveToNext());
        }

    }

}