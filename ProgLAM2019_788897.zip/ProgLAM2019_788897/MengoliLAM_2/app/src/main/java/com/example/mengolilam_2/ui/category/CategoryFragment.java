package com.example.mengolilam_2.ui.category;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.text.InputType;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import com.example.mengolilam_2.GestioneDB;
import com.example.mengolilam_2.R;
import com.example.mengolilam_2.TaskListActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.content.res.Resources;


public class CategoryFragment extends Fragment {

    private CategoryViewModel categoryViewModel;
    private View root;
    private Button btnUno, btnTre, btnDue, btnQuattro,btnCinque, btnSei;
    private GestioneDB db;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        categoryViewModel =
                ViewModelProviders.of(this).get(CategoryViewModel.class);
        root = inflater.inflate(R.layout.fragment_category, container, false);

        btnUno = root.findViewById(R.id.btnuno);
        btnDue = root.findViewById(R.id.btndue);
        btnTre = root.findViewById(R.id.btntre);
        btnQuattro = root.findViewById(R.id.btnquattro);
        btnCinque = root.findViewById(R.id.btncinque);
        btnSei = root.findViewById(R.id.btnsei);

        db = new GestioneDB(root.getContext());
        db.open();

        setButtonText();

        Resources res = getResources();

        View view = getActivity().findViewById(R.id.drawer_layout);
        FloatingActionButton fab = view.findViewById(R.id.fab);
        if (btnSei.getVisibility() == View.VISIBLE){
            fab.hide();
        }
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(root.getContext());
                builder.setTitle("Add new category");

                // Set up the input
                final EditText input = new EditText(root.getContext());
                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                input.setInputType(InputType.TYPE_CLASS_TEXT );
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        db.inserisciCategoria(input.getText().toString());
                        if(btnCinque.getVisibility() != View.VISIBLE){
                            btnCinque.setVisibility(View.VISIBLE);
                            btnCinque.setText(input.getText().toString());
                        }else{
                            btnSei.setVisibility(View.VISIBLE);
                            btnSei.setText(input.getText().toString());
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });


        btnUno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaskListActivity.class);
                intent.putExtra("category_title", btnUno.getText().toString());
                startActivity(intent);
            }

        });

        btnDue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaskListActivity.class);
                intent.putExtra("category_title", btnDue.getText().toString());
                startActivity(intent);
            }
        });

        btnTre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaskListActivity.class);
                intent.putExtra("category_title", btnTre.getText().toString());
                startActivity(intent);
            }
        });

        btnQuattro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaskListActivity.class);
                intent.putExtra("category_title", btnQuattro.getText().toString());
                startActivity(intent);
            }
        });

        btnCinque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaskListActivity.class);
                intent.putExtra("category_title", btnCinque.getText().toString());
                startActivity(intent);
            }
        });

        btnSei.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TaskListActivity.class);
                intent.putExtra("category_title", btnSei.getText().toString());
                startActivity(intent);
            }
        });

        return root;
    }

    public void setButtonText(){
        Integer i= 0;
        Cursor c = db.ottieniCategorie();
        if(c.moveToFirst()){
            do{
                i = c.getInt(0);
                if(c.getString(1) != "") {
                    switch (i) {
                        case 1:
                            btnUno.setText(c.getString(1));
                            btnUno.setVisibility(View.VISIBLE);
                            break;
                        case 2:
                            btnDue.setText(c.getString(1));
                            btnDue.setVisibility(View.VISIBLE);
                            break;
                        case 3:
                            btnTre.setText(c.getString(1));
                            btnTre.setVisibility(View.VISIBLE);
                            break;
                        case 4:
                            btnQuattro.setText(c.getString(1));
                            btnQuattro.setVisibility(View.VISIBLE);
                            break;
                        case 5:
                            btnCinque.setText(c.getString(1));
                            btnCinque.setVisibility(View.VISIBLE);
                            break;
                        case 6:
                            btnSei.setText(c.getString(1));
                            btnSei.setVisibility(View.VISIBLE);
                            break;
                    }
                }
            }while(c.moveToNext());
        }
    }

}