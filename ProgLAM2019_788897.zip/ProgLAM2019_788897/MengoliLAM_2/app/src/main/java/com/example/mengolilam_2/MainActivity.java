package com.example.mengolilam_2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.view.View;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private TextView category;
    private FirebaseAuth mAuth;
    private GestioneDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = new GestioneDB(this);
        db.open();
        db.onCreate();

        mAuth = FirebaseAuth.getInstance();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNote();
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_calendar, R.id.nav_category, R.id.nav_shopping,
                R.id.nav_graphs)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.action_settings){
            mAuth.signOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

   private void addNote() {
        Intent intent = new Intent(this, TaskActivity.class);
        intent.putExtra("activity", "MainActivity");
        startActivity(intent);
        finish();
    }

    //click su una lista per aprire la lista degli elementi
    public void openShopListDetail(View v){
        TextView id = v.findViewById(R.id.shoplist_id);
       Intent intent = new Intent(MainActivity.this, ShoppingItem.class);
       intent.putExtra("idshoplist",id.getText().toString());
        startActivity(intent);
    }

    //click sul nome di un grafico
    public void openGraph(View view){
        String graph = "";
        Intent intent = new Intent(this,GraphActivity.class);
        if(view.getId() == R.id.graph_uno){
            graph = "uno";
        }else {
            graph = "due";
        }
        intent.putExtra("graph",graph);
        startActivity(intent);
    }

    public void openTaskDetail(View v){
        TextView id = v.findViewById(R.id.row_task_id);
        Intent intent = new Intent(MainActivity.this, TaskActivity.class);
        intent.putExtra("id",id.getText().toString());
        intent.putExtra("activity", "MainActivity");
        startActivity(intent);
    }

    public void deleteTask(View v){
        View parent =  v.getRootView();
        TextView id = parent.findViewById(R.id.row_task_id);
        Boolean bool = db.cancellaTask(Integer.parseInt(id.getText().toString()));
    }

    public void deleteShopList(View v){
        View parent =  v.getRootView();
        TextView id = parent.findViewById(R.id.shoplist_id);
        Boolean bool = db.eliminaShoppingList(Integer.parseInt(id.getText().toString()));
    }
}
