package com.example.mengolilam_2;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ShopItemCursorAdapter extends CursorAdapter {

    private GestioneDB db;
    public ShopItemCursorAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
        db = new GestioneDB(context);
    }


    // The newView method is used to inflate a new view and return it,
    // you don't bind any data to the view at this point.
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.shoppingitem_listview, parent, false);
    }

    // The bindView method is used to bind all data to a given view
    // such as setting the text on a TextView.
    @Override
    public void bindView(View view, Context context, Cursor c) {

        TextView id  = view.findViewById(R.id.shopitem_id);
        TextView item = view.findViewById(R.id.row_shopitem_item);
        TextView quantity = view.findViewById(R.id.row_shopitem_qta);
        TextView price = view.findViewById(R.id.row_shopitem_price);
        ImageButton delete = view.findViewById(R.id.delete);

        c.moveToFirst();
        id.setText(c.getString(0));

        if(c.getString(1) != ""){
            item.setText(c.getString(1));
        }
        if(c.getString(2) != ""){
            quantity.setText(c.getString(2));
        }
        if(c.getString(3) != ""){
            price.setText(c.getString(3));
        }

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean bool = db.eliminaShoppingItem(Integer.parseInt( id.getText().toString()));
            }
        });

    }
}
