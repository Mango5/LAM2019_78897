package com.example.mengolilam_2.ui.graphs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import android.widget.TextView;
import com.example.mengolilam_2.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class GraphsFragment extends Fragment {

    private GraphsViewModel graphsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        graphsViewModel =
                ViewModelProviders.of(this).get(GraphsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_graphs, container, false);
        TextView nome = root.findViewById(R.id.row_graph_nome);

        View view = getActivity().findViewById(R.id.drawer_layout);
        FloatingActionButton fab = view.findViewById(R.id.fab);
        fab.hide();

        return root;
    }

}