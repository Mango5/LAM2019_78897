package com.example.mengolilam_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Random;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import me.ithebk.barchart.BarChart;
import me.ithebk.barchart.BarChartModel;
import android.graphics.Color;
import com.example.mengolilam_2.ui.shopping.ShoppingFragment;


public class GraphActivity extends AppCompatActivity {

    private BarChart chart;
    private Spinner spinner;
    private String graph;
    private GestioneDB db;
    private ArrayList<String> arrCat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        db = new GestioneDB(this);
        db.open();

        spinner = findViewById(R.id.mese);
        chart = findViewById(R.id.chart);
        Intent intent = getIntent();
        graph = intent.getStringExtra("graph");
        riempiSpinner();
        switch (graph) {
            case "uno":
                barGraphUno();
                break;
            case "due":
                barGraphDue();
                break;
        }
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (graph) {
                    case "uno":
                        chart.clearAll();
                        barGraphUno();
                        break;
                    case "due":
                        chart.clearAll();
                        barGraphDue();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void riempiSpinner() {
        switch (graph) {
            case "uno":
                //riempio lo spinner con i mesi
                ArrayAdapter<CharSequence> adapter_month = ArrayAdapter.createFromResource(this, R.array.months_array, android.R.layout.simple_spinner_item);
                adapter_month.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter_month);
                break;
            case "due":
                //riempio lo spinner con le categorie
                caricaListaCategoria();
                ArrayAdapter<String> adpCat = new ArrayAdapter<>(GraphActivity.this, android.R.layout.simple_list_item_1, arrCat);
                adpCat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adpCat);
                break;

        }

    }

    private void barGraphUno() {
        caricaListaCategoria();
        Integer month = getSelectedMonth();
        for (Integer i = 1; i < arrCat.size() + 1; i++) {
            Cursor c = db.ottieniCountTaskMese(i, month);
            c.moveToFirst();
            BarChartModel barChartModel = new BarChartModel();
            barChartModel.setBarValue(c.getInt(1));
            Random rnd = new Random();
            barChartModel.setBarColor(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
            barChartModel.setBarTag(c.getInt(1));
            barChartModel.setBarText(arrCat.get(i - 1));
            chart.addBar(barChartModel);
        }
    }

    private void barGraphDue() {
        String categoria = spinner.getSelectedItem().toString();
        Cursor p = db.ottieniCountTaskCategoria(categoria, "pending");
        p.moveToFirst();
        BarChartModel barChartModel = new BarChartModel();
        barChartModel.setBarValue(p.getInt(1));
        barChartModel.setBarColor(R.color.color_pending);
        barChartModel.setBarText("pending");
        chart.addBar(barChartModel);

        Cursor o = db.ottieniCountTaskCategoria(categoria, "ongoing");
        o.moveToFirst();
        barChartModel = new BarChartModel();
        barChartModel.setBarValue(o.getInt(1));
        barChartModel.setBarColor(R.color.color_ongoing);
        barChartModel.setBarText("ongoing");
        chart.addBar(barChartModel);

        Cursor c = db.ottieniCountTaskCategoria(categoria, "completed");
        c.moveToFirst();
        barChartModel = new BarChartModel();
        barChartModel.setBarValue(c.getInt(1));
        barChartModel.setBarColor(R.color.color_completed);
        barChartModel.setBarText("completed");
        chart.addBar(barChartModel);

    }

    private void caricaListaCategoria() {
        arrCat = new ArrayList<>();
        Integer i = 0;
        Cursor c = db.ottieniCategorie();
        if (c.moveToFirst()) {
            do {
                i = c.getInt(0);
                arrCat.add(c.getString(1));
            } while (c.moveToNext());
        }
    }

    private int getSelectedMonth() {
        int month = 0;
        switch (spinner.getSelectedItem().toString()) {
            case "Jauary":
                month = 1;
                break;
            case "February":
                month = 2;
                break;
            case "March":
                month = 3;
                break;
            case "April":
                month = 4;
                break;
            case "May":
                month = 5;
                break;
            case "June":
                month = 6;
                break;
            case "July":
                month = 7;
                break;
            case "August":
                month = 8;
                break;
            case "September":
                month = 9;
                break;
            case "October":
                month = 10;
                break;
            case "November":
                month = 11;
                break;
            case "December":
                month = 12;
                break;
            default:
                month = 1;
                break;
        }
        return month;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(GraphActivity.this, ShoppingFragment.class);
        startActivity(intent);
    }
}
