package com.example.mengolilam_2.ui.shopping;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.mengolilam_2.GestioneDB;
import com.example.mengolilam_2.R;

public class ShopListCursorAdapter extends CursorAdapter {

    private GestioneDB db;

    public ShopListCursorAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
        db = new GestioneDB(context);
    }


    // The newView method is used to inflate a new view and return it,
    // you don't bind any data to the view at this point.
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.shoppinglist_listview, parent, false);
    }

    // The bindView method is used to bind all data to a given view
    // such as setting the text on a TextView.
    @Override
    public void bindView(View view, Context context, Cursor c) {

        TextView id  = view.findViewById(R.id.shoplist_id);
        TextView nome = view.findViewById(R.id.row_shoplist_nome);
        TextView totale = view.findViewById(R.id.row_shoplist_totale);
        ImageButton delete = view.findViewById(R.id.delete);

        c.moveToFirst();
        id.setText(c.getString(0));

        if(c.getString(1) != ""){
            nome.setText(c.getString(1));
        }
        Double tot = c.getDouble(2);
        totale.setText(String.valueOf(tot));

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean bool = db.eliminaShoppingList(Integer.parseInt( id.getText().toString()));
            }
        });
    }
}
