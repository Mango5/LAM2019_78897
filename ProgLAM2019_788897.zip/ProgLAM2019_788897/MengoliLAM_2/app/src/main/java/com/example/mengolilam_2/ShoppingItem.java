package com.example.mengolilam_2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;


public class ShoppingItem extends AppCompatActivity {

    private ListView list;
    private TextView item,qta,price;
    private Button btnInsert;
    private GestioneDB db;
    private Integer idlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_item);

        list = findViewById(R.id.list_shoppingitem);
        item = findViewById(R.id.insert_item);
        qta = findViewById(R.id.insert_qta);
        price = findViewById(R.id.insert_prezzo);
        btnInsert = findViewById(R.id.btn_add_item);
        db = new GestioneDB(this);
        db.open();
        idlist = Integer.parseInt(getIntent().getStringExtra("idshoplist"));
        visualizzaList();

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str ="{";
                if(item.getText().toString() != ""){
                    str = str + "'item': '" + item.getText().toString() + "'";
                }
                if(qta.getText().toString() != ""){
                    str = str + ", 'quantita': " + qta.getText().toString() + "";
                }
                if(item.getText().toString() != ""){
                    str = str + ", 'prezzo': " + price.getText().toString() + "";
                }
                str = str + "}";
                Long id = db.inserisciShoppingItem(str, idlist);
                aggiornaTotale();
                visualizzaList();
            }
        });
    }

    public void visualizzaList() {
        Cursor c = db.ottieniShoppingItem(idlist);
        if(c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {
                    ShopItemCursorAdapter itemadp = new ShopItemCursorAdapter(this, c);
                    itemadp.changeCursor(c);
                    list.setAdapter(itemadp);
                } while (c.moveToNext());
            }
        }
    }

    public void aggiornaTotale(){
        Cursor d = db.conteggioTotale(idlist);
        Double tot = 0.0;
        d.moveToFirst();
        do{
            tot = tot + d.getDouble(1);
        }while(d.moveToNext());
        String str = "{'totale':" + tot + "}";
        Boolean b = db.aggiornaShoppingList(str,idlist);
    }

    public void deleteShopItem(View v){
        View parent =  v.getRootView();
        TextView id = parent.findViewById(R.id.shopitem_id);
        Boolean bool = db.eliminaShoppingItem(Integer.parseInt(id.getText().toString()));
        if(bool) visualizzaList();
    }
}
