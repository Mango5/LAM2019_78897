package com.example.mengolilam_2;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.view.View;

import java.sql.Date;
import java.util.Calendar;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.Button;
import java.util.ArrayList;
import android.content.Intent;
import android.app.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Locale;
import android.database.Cursor;
import java.util.concurrent.TimeUnit;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class TaskActivity extends AppCompatActivity {

    private Button addRemind, btnStato;
    private ArrayList<String> mData;
    private Context mContext;
    private String senderClick, datainizio;

    private FloatingActionButton save;
    private TextView mDateTimeTextS, mDateTimeTextE, taskID;
    private EditText titolo, luogo, note, priorita,stato;
    private Spinner spinner_cat;
    private ListView reminder_list;
    private ReminderSpinnerAdapter adapter_rem;
    private GestioneDB db;
    private String activityRet = "MainActivity";
    private NotificationManager notificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);
        mContext = this;
        db = new GestioneDB(this);
        db.open();


        taskID = findViewById(R.id.id_task);
        titolo = findViewById(R.id.title_task);
        save = findViewById(R.id.saveTask);
        luogo = findViewById(R.id.place_task);
        mDateTimeTextS = findViewById(R.id.datetime_start_text);
        mDateTimeTextE = findViewById(R.id.datetime_end_text);
        note = findViewById(R.id.note_task);
        priorita = findViewById(R.id.priority_text);
        stato = findViewById(R.id.state_text);
        btnStato = findViewById(R.id.state_button);
        reminder_list = (ListView) findViewById(R.id.reminder_list);

        riempiSpinnerCategoria();
        //chiamata dall'Activity TaskListActivity
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("id")){
            String str = intent.getStringExtra("id");
            taskID.setText(str);
            riempiPagina();
            riempiListaReminder();
        }else { //chiamata dall'Activity MainActivity
            //listView of spinner for reminder
            mData = new ArrayList<String>();
            mData.add("Remind");
            adapter_rem = new ReminderSpinnerAdapter(mData, this);
            reminder_list.setAdapter(adapter_rem);
            stato.setEnabled(false);
            btnStato.setBackgroundColor(getResources().getColor(R.color.color_pending));
        }
        activityRet = intent.getStringExtra("activity");

        addRemind = findViewById(R.id.add_new_reminder);
        addRemind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mData = new ArrayList<String>();
                mData.add("Remind");
                ReminderSpinnerAdapter adapter_rem_new = new ReminderSpinnerAdapter(mData, mContext);
                reminder_list.setAdapter(adapter_rem_new);
            }
        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String task =costruisciStringa();
                if( taskID.getText().toString() != "" ){
                    Boolean agg = db.aggiornaTask(task, Integer.parseInt(taskID.getText().toString()));
                    if(agg){
                        db.cancellaNotifica(Integer.parseInt(taskID.getText().toString()));
                    }
                }else {
                    long id = db.inserisciTask(task);
                    taskID.setText(String.valueOf(id));

                }
                inserisciNotifiche();
                Intent intent;
                switch (activityRet){
                    case "TaskListActivity":
                        intent = new Intent(TaskActivity.this, TaskListActivity.class);
                        intent.putExtra("category_title",spinner_cat.getSelectedItem().toString());
                        break;
                    default:
                        intent = new Intent(TaskActivity.this, MainActivity.class);
                        break;
                }
                startActivity(intent);
            }
        });

    }

    public String costruisciStringa(){
        String[] dtE = (mDateTimeTextE.getText().toString()).split(" ");
        String[] dtS = (mDateTimeTextS.getText().toString()).split(" ");
        datainizio = dtS[0];
        String str = "{";
        if (titolo.getText().toString() != ""){
            str = str + "'titolo': '" + titolo.getText().toString() + "'";
        }
        if( taskID.getText().toString() != "" ) {
            str = str + ", 'stato': '"+ stato.getText().toString() + "'";
        }else{
            str = str + ", 'stato': 'pending'";
        }
        if (priorita.getText().toString() != ""){
            str = str + ", 'priorita': " + priorita.getText().toString() + "";
        }
        if (spinner_cat.getSelectedItem().toString() != ""){
            str = str + ", 'categoria' : '" + spinner_cat.getSelectedItem().toString() + "'";
        }
        if (dtS[0] != ""){
            str = str + ", 'datainizio' : '" + dtS[0] + "'";
            if (dtS[1] != ""){
                str = str + ", 'orainizio' : '" + dtS[1] + "'";
            }
        }

        if (dtE[0] != ""){
            str = str + ", 'datafine' : '" + dtE[0] + "'";
            if (dtE[1] != ""){
                str = str + ", 'orafine' : '" + dtE[1] + "'";
            }
        }
        if (note.getText().length()  > 0){
            str = str + ", 'descrizione':  '" + note.getText() + "'";
        }
        if (luogo.getText().length() > 0){
            str = str + ", 'luogo' : " + luogo.getText() + "";
        }

            str = str + "}";
        return str;
    }

    public void riempiPagina(){
        Cursor c = db.ottieniTask(Integer.parseInt(taskID.getText().toString()));
        c.moveToFirst();
        if(c.getString(1) != "") {
            titolo.setText(c.getString(1));
        }
        if(c.getString(4) != "") {
            priorita.setText(String.valueOf(c.getInt(4)));
        }
        if( c.getString(2) != "") {
            stato.setText(c.getString(2));
            switch (c.getString(2)){
                case "pending":
                    btnStato.setBackgroundColor(getResources().getColor(R.color.color_pending));
                    break;
                case "ongoing":
                    btnStato.setBackgroundColor(getResources().getColor(R.color.color_ongoing));
                    break;
                case "completed":
                    btnStato.setBackgroundColor(getResources().getColor(R.color.color_completed));
                    break;
            }
        }
        if( c.getString(3) != "") {
            switch (c.getString(3)) {
                case "Work":
                    spinner_cat.setSelection(0);
                    break;
                case "University":
                    spinner_cat.setSelection(1);
                    break;
                case "Sport":
                    spinner_cat.setSelection(2);
                    break;
                case "Other":
                    spinner_cat.setSelection(3);
                    break;
            }
        }
        if(c.getString(9) != "") {
            luogo.setText(c.getString(9));
        }
        if(c.getString(5) != "") {
            mDateTimeTextS.setText(c.getString(5) + " " + c.getString(6));
        }
        if(c.getString(7) != null) {
            mDateTimeTextE.setText( c.getString(7)+ " " + c.getString(8));
        }
        if(c.getString(10) != "") {
            note.setText(c.getString(10));
        }

    }

    public void setDateTime(View v){
       // senderClick = v.getResources().getResourceName(v.getId());
        senderClick = v.getResources().getResourceEntryName(v.getId());
        Intent intent = new Intent(TaskActivity.this, DateTimeDialog.class);
        intent.putExtra("sender", senderClick);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dataIntent) {
        super.onActivityResult(requestCode, resultCode, dataIntent);

        // The returned result data is identified by requestCode.
        // The request code is specified in startActivityForResult(intent, REQUEST_CODE_1); method.
        switch (requestCode)
        {
            // This request code is set by startActivityForResult(intent, REQUEST_CODE_1) method.
            case 1:

                if(resultCode == RESULT_OK)
                {
                    switch (senderClick){
                        case "datetime_start":
                            String Datestart = dataIntent.getStringExtra("date_start");
                            mDateTimeTextS.setText(Datestart);
                            break;
                        case "datetime_end":
                            String Dateend = dataIntent.getStringExtra("date_end");
                            mDateTimeTextE.setText(Dateend);
                            break;
                    }

                }
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent;
        switch (activityRet){
            case "TaskListActivity":
                intent = new Intent(TaskActivity.this, TaskListActivity.class);
                intent.putExtra("category_title",spinner_cat.getSelectedItem().toString());
                break;
            default:
                intent = new Intent(TaskActivity.this, MainActivity.class);
                break;
        }
        startActivity(intent);
        finish();

    }

    private void startAlarm(boolean isNotification, long rem, long idnot) {
        try {
            AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent myIntent;
            PendingIntent pendingIntent;

            // SET TIME HERE
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());

            calendar.setTime(sdf.parse(mDateTimeTextS.getText().toString()));

            myIntent = new Intent(TaskActivity.this, AlarmNotificationReceiver.class);
            myIntent.putExtra("titolo", titolo.getText().toString());
            myIntent.putExtra("taskid", taskID.getText().toString());
            myIntent.putExtra("notid", taskID.getText().toString());
            pendingIntent = PendingIntent.getBroadcast(this, 0, myIntent, 0);

            manager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis() + rem, pendingIntent);

        }catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onStart(){
        super.onStart();

    }

    public void inserisciNotifiche(){
        if (reminder_list.getAdapter().getCount() > 0){
            for ( int i = 0;i < reminder_list.getAdapter().getCount(); i++ ){
                Spinner sp = reminder_list.findViewById(R.id.row_item_spinner);
                //String not = reminder_list.getAdapter().getItem(i).toString();
                String not = sp.getSelectedItem().toString();
               //String not = spinner.getText().toString();
                Integer idrem;
                Long time;
                switch (not){
                    case "5 minuti prima":
                        idrem = 1;
                        time = TimeUnit.MINUTES.toMillis(5);
                        break;
                    case "10 minuti prima":
                        idrem = 2;
                        time = TimeUnit.MINUTES.toMillis(10);
                        break;
                    case "15 minuti prima":
                        idrem = 3;
                        time = TimeUnit.MINUTES.toMillis(15);
                        break;
                    case "30 minuti prima":
                        idrem = 4;
                        time = TimeUnit.MINUTES.toMillis(30);
                        break;
                    case "1 ora prima":
                        idrem = 5;
                        time = TimeUnit.MINUTES.toMillis(60);
                        break;
                    case "2 ore prima":
                        idrem = 6;
                        time = TimeUnit.MINUTES.toMillis(120);
                        break;
                    case "24 ore prima":
                        idrem = 7;
                        time = TimeUnit.HOURS.toMillis(24);
                        break;
                    case "2 giorni prima":
                        idrem = 8;
                        time = TimeUnit.HOURS.toMillis(48);
                        break;
                    case "1 settimana prima":
                        idrem = 9;
                        time = TimeUnit.DAYS.toMillis(7);
                        break;
                    default:
                        idrem = 0;
                        time = null;
                        break;
                }

                if(idrem != 0){
                    Long idnot = db.inserisciNotifiche(idrem, Integer.parseInt(taskID.getText().toString()));
                    startAlarm(true,time, idnot);
                }
                startAlarm(true,0,0);
            }
        }
    }


    public void riempiSpinnerCategoria(){
        ArrayList<String> arrCat = new ArrayList<>();
        Integer i = 0;
        Cursor c = db.ottieniCategorie();
        if(c.moveToFirst()){
            do{
                 i = c.getInt(0);
                arrCat.add(c.getString(1));
            }while(c.moveToNext() );
        }
        spinner_cat = (Spinner) findViewById(R.id.category_spinner);
        ArrayAdapter<String> adpCat = new ArrayAdapter<>(TaskActivity.this,android.R.layout.simple_list_item_1,arrCat);
        adpCat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_cat.setAdapter(adpCat);
    }

    public void riempiListaReminder() {
        Cursor n = db.ottieniNotifiche(Integer.parseInt(taskID.getText().toString()));
        if(n.getCount() == 0) {
            mData = new ArrayList<String>();
            mData.add("Remind");
            adapter_rem = new ReminderSpinnerAdapter(mData, this);
            reminder_list.setAdapter(adapter_rem);
        }
        if (n.moveToFirst()) {
            do {
                mData = new ArrayList<String>();
                mData.add("Remind");
                adapter_rem = new ReminderSpinnerAdapter(mData, this);
                reminder_list.setAdapter(adapter_rem);
                View view = adapter_rem.getView(0,null,null);
                Spinner spinner = view.findViewById(R.id.row_item_spinner);
                spinner.setSelection(n.getInt(1)+1);
                notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.cancel(n.getInt(1));
            } while (n.moveToNext());
        }
    }
}
