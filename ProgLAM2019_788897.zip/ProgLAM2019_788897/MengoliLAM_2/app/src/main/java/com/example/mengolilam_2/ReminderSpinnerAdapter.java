package com.example.mengolilam_2;

import android.database.Cursor;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.view.ViewGroup;
import android.widget.Spinner;
import android.view.LayoutInflater;
import com.example.mengolilam_2.R;


    public class ReminderSpinnerAdapter extends BaseAdapter {

        private ArrayList<String> mData;
        private Context mContext;
         private GestioneDB db;

        public ReminderSpinnerAdapter(ArrayList<String> data, Context context) {
            mData = data;
            mContext = context;
            db = new GestioneDB(mContext);
        }

        @Override
        public int getCount() {
            return mData.size();
        }

        @Override
        public Object getItem(int position) {
            return mData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.spinner_reminder_listview, null);
            }
            TextView textView = (TextView) view.findViewById(R.id.row_item_textview);
            Spinner spinner = (Spinner) view.findViewById(R.id.row_item_spinner);

            db.open();
            Cursor c = db.ottieniTuttiReminder();
            Integer i=0;
            String[] rem= new String[10];
            rem[i] = "Nessuno";
            if(c.moveToFirst()) {
                do {
                     i  = c.getInt(0);
                        String a = c.getString(1);

                    if (a != "") {
                            rem[i] = a;
                        }
                } while ( c.moveToNext() && i < 9);
            }
            textView.setText(mData.get(0));
            ArrayAdapter<String> a =new ArrayAdapter<String>(mContext,android.R.layout.simple_list_item_1, rem);
            a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(a);

            //ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(mContext,R.array.reminder_array, android.R.layout.simple_spinner_item);
           // spinner.setAdapter(adapter);
            return view;
        }
    }

