package com.example.mengolilam_2.ui.calendar;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import androidx.lifecycle.ViewModelProviders;
import java.util.*;
import java.util.concurrent.CancellationException;
import android.widget.CalendarView;
import android.database.Cursor;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mengolilam_2.GestioneDB;
import com.example.mengolilam_2.R;
import com.example.mengolilam_2.TaskActivity;
import com.example.mengolilam_2.TaskCursorAdapter;
import com.example.mengolilam_2.TaskListActivity;
import com.example.mengolilam_2.ui.category.CategoryViewModel;

public class CalendarFragment extends Fragment {

    private CalendarViewModel calendarViewModel;
    private CalendarView mCalendarView;
    private Calendar mCalendar;
    CategoryViewModel categoryViewModel;
    private GestioneDB db ;
    private ListView list;
    private  View root;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        categoryViewModel =
                ViewModelProviders.of(this).get(CategoryViewModel.class);
        root = inflater.inflate(R.layout.fragment_calendar, container, false);
        super.onCreate(savedInstanceState);
        db = new GestioneDB(root.getContext());
        db.open();

        mCalendar = Calendar.getInstance();

        list = root.findViewById(R.id.task_list);
        mCalendarView = (CalendarView) root.findViewById(R.id.calendarView);
        String data = setDate(mCalendar);
        Cursor c = db.ottieniTaskData(data);
        visualizzaTask(c);

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String day = String.valueOf(dayOfMonth);
                String mm = String.valueOf(month);

                if(dayOfMonth < 10) day = "0"+ day ;
                if(month <10) mm = "0" + mm;

                String data = day + "/" +  month + "/" + year ;
                Cursor d = db.ottieniTaskData(data);
                visualizzaTask(d);
            }
        });
        return root;
    }

    public void visualizzaTask(Cursor c) {
        if (c.moveToFirst()) {
            do {
                TaskCursorAdapter taskadp = new TaskCursorAdapter(root.getContext(), c);
                taskadp.changeCursor(c);
                list.setAdapter(taskadp);
            } while (c.moveToNext());
        }

    }


    private String setDate(Calendar calendar){
        String day = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
        String month = String.valueOf(calendar.get(Calendar.MONTH)+1);

        if(calendar.get(Calendar.DAY_OF_MONTH) < 10) day = "0"+ day ;
        if(calendar.get(Calendar.MONTH)+1 <10) month = "0" + month;

        String data = day + "/" +  month + "/" + calendar.get(Calendar.YEAR) ;
        return data;
    }



}