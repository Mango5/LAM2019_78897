package com.example.mengolilam_2;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;


public class TaskCursorAdapter extends CursorAdapter {

    private Cursor mCursor;
    private Context mContext;
    private GestioneDB db = new GestioneDB(mContext);

    public TaskCursorAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }


    // The newView method is used to inflate a new view and return it,
    // you don't bind any data to the view at this point.
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.task_listview, parent, false);
    }

    // The bindView method is used to bind all data to a given view
    // such as setting the text on a TextView.
    @Override
    public void bindView(View view, Context context, Cursor c) {

        // Find fields to populate in inflated template
        TextView id = (TextView) view.findViewById(R.id.row_task_id);
        TextView titolo = (TextView) view.findViewById(R.id.row_task_title);
        TextView dataS = (TextView) view.findViewById(R.id.row_task_dateS);
        TextView dataE = (TextView) view.findViewById(R.id.row_task_dateE);
        TextView priorita = (TextView) view.findViewById(R.id.row_task_priority);
        Button stato = view.findViewById(R.id.row_task_stato);
        ImageButton delete = view.findViewById(R.id.delete);
        // Extract properties from cursor and Populate fields with extracted properties

        id.setText(c.getString(0));

        if(c.getString(1) != "") {
            titolo.setText(c.getString(1));
        }
        if( c.getString(3) != "") {
            dataS.setText(c.getString(3));
        }else {
            dataS.setText(" ");
        }
        if(c.getString(4) != "") {
            dataE.setText(c.getString(4));
        }else {
            dataE.setText(" ");
        }
        if(c.getString(2) != "") {
            priorita.setText("Priority: " + c.getString(2));
        }else {
            priorita.setText("Priority: undefined" );
        }
        if(c.getString(5) != ""){
            switch (c.getString(5)){
                case "pending":
                    stato.setBackgroundColor(view.getResources().getColor(R.color.color_pending));
                    break;
                case "ongoing":
                    stato.setBackgroundColor(view.getResources().getColor(R.color.color_ongoing));
                    break;
                case "completed":
                    stato.setBackgroundColor(view.getResources().getColor(R.color.color_completed));
                    break;
            }
        }


    }

}
