package com.example.mengolilam_2;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;
import android.widget.DatePicker;
import android.widget.TimePicker;

import java.util.Calendar;

public class DateTimeDialog extends AppCompatActivity {

    private int mYear, mMonth, mHour, mMinute, mDay;
    private String mDate;
    private String mTime;
    private Calendar mCalendar;
    private String sender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datetime_dialog);
        this.setFinishOnTouchOutside(false);

        Intent intent = getIntent();
         sender = intent.getStringExtra("sender");

        DatePicker datePicker = findViewById(R.id.datePicker);
        TimePicker timePicker = findViewById(R.id.timePicker);


        // Initialize default values

        mCalendar = Calendar.getInstance();
        mHour = mCalendar.get(Calendar.HOUR_OF_DAY);
        mMinute = mCalendar.get(Calendar.MINUTE);
        mYear = mCalendar.get(Calendar.YEAR);
        mMonth = mCalendar.get(Calendar.MONTH) ;
        mDay = mCalendar.get(Calendar.DATE);

        String m = String.valueOf(mMonth+1);
        String d = String.valueOf(mDay);
        String h = String.valueOf(mHour);
        String min = String.valueOf(mMinute);
        if(mMonth < 10 )  m = "0"+ m;
        if(mDay < 10 ) d = "0"+ d;
        if(mHour < 10 )  h = "0"+ h;
        if(mMinute < 10 )  min = "0"+ min;
        mDate = d + "/" + m + "/" + mYear;
        mTime = h + ":" + min;

        datePicker.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String day = String.valueOf(dayOfMonth);
                String month = String.valueOf(monthOfYear+1);

                if(dayOfMonth < 10) day = "0"+ day ;
                if(monthOfYear<10) month = "0" + month;
                mDate = day + "/" + month + "/" + year;
            }
        });

        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                String ore = String.valueOf(hourOfDay);
                String min = String.valueOf(minute);

                if(hourOfDay < 10) ore = "0"+ ore ;
                if(minute<10) min = "0" + min;
                mTime = ore + ":" + min;
            }
        });

        Button close_button = (Button) findViewById(R.id.close_button);
        close_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button done_button = (Button) findViewById(R.id.done_button);
        done_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                String datetime = mDate + " " + mTime;
                switch (sender) {
                    case "datetime_start":
                        intent.putExtra("date_start", datetime);
                        break;
                    case "datetime_end":
                        intent.putExtra("date_end", datetime);
                        break;
                }
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        String datetime = mDate + " " + mTime;
        switch (sender) {
            case "datetime_start":
                intent.putExtra("date_start", datetime);
                break;
            case "datetime_end":
                intent.putExtra("date_end", datetime);
                break;
        }
        setResult(RESULT_OK, intent);
        finish();
    }
}
